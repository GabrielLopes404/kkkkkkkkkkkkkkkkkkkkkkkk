import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Check, Sparkles } from "lucide-react";
import { useState, useRef } from "react";
import { motion, useInView } from "framer-motion";

const plans = [
  {
    name: "Pessoal",
    description: "Para freelancers e pequenos negócios",
    monthlyPrice: 49,
    annualPrice: 470,
    features: [
      "Até 50 clientes",
      "Faturas ilimitadas",
      "Relatórios básicos",
      "1 usuário",
      "Suporte por email"
    ],
    cta: "Começar teste grátis"
  },
  {
    name: "Empresarial",
    description: "Para empresas em crescimento",
    monthlyPrice: 149,
    annualPrice: 1430,
    popular: true,
    features: [
      "Clientes ilimitados",
      "Faturas ilimitadas",
      "Relatórios avançados",
      "Até 5 usuários",
      "API de integração",
      "Suporte prioritário",
      "Automação de cobranças"
    ],
    cta: "Começar teste grátis"
  },
  {
    name: "Enterprise",
    description: "Para grandes organizações",
    monthlyPrice: null,
    annualPrice: null,
    features: [
      "Tudo do Empresarial",
      "Usuários ilimitados",
      "SLA garantido",
      "Gerente de conta dedicado",
      "Onboarding personalizado",
      "Customizações"
    ],
    cta: "Falar com vendas"
  }
];

export default function PricingSection() {
  const [annual, setAnnual] = useState(false);
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.2 });

  return (
    <section id="precos" className="relative py-24 px-4 sm:px-6 lg:px-8 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-background via-primary/5 to-background" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(59,130,246,0.1),transparent_50%)]" />
      
      <div ref={ref} className="max-w-[1280px] mx-auto relative z-10">
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-12"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={isInView ? { opacity: 1, scale: 1 } : {}}
            transition={{ delay: 0.2, duration: 0.5 }}
            className="inline-block mb-4"
          >
            <span className="px-4 py-2 rounded-full bg-gradient-to-r from-primary/20 to-primary/10 border border-primary/30 text-sm font-medium text-primary backdrop-blur-sm flex items-center gap-2">
              <Sparkles className="h-4 w-4" />
              Preços Transparentes
            </span>
          </motion.div>

          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-semibold mb-4 bg-gradient-to-r from-foreground via-foreground to-foreground/70 bg-clip-text text-transparent" data-testid="text-pricing-title">
            Planos para todos os tamanhos
          </h2>
          <p className="text-lg sm:text-xl text-muted-foreground mb-8" data-testid="text-pricing-subtitle">
            Escolha o plano ideal para o seu negócio. Todos com 7 dias grátis.
          </p>
          
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={isInView ? { opacity: 1, scale: 1 } : {}}
            transition={{ delay: 0.4, duration: 0.5 }}
            className="flex items-center justify-center gap-3"
          >
            <span className={`text-sm font-medium transition-all duration-300 ${!annual ? 'text-foreground scale-110' : 'text-muted-foreground'}`}>
              Mensal
            </span>
            <motion.button
              whileTap={{ scale: 0.95 }}
              onClick={() => setAnnual(!annual)}
              className={`relative inline-flex h-7 w-12 items-center rounded-full transition-all duration-300 shadow-inner ${
                annual ? 'bg-gradient-to-r from-primary to-primary/80' : 'bg-muted'
              }`}
              data-testid="button-pricing-toggle"
            >
              <motion.span
                layout
                className="inline-block h-5 w-5 transform rounded-full bg-white shadow-lg"
                animate={{ x: annual ? 26 : 4 }}
                transition={{ type: "spring", stiffness: 500, damping: 30 }}
              />
            </motion.button>
            <span className={`text-sm font-medium transition-all duration-300 ${annual ? 'text-foreground scale-110' : 'text-muted-foreground'}`}>
              Anual
            </span>
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              whileHover={{ scale: 1.05 }}
            >
              <Badge className="ml-2 bg-gradient-to-r from-green-600 to-emerald-600 border-0 shadow-lg">
                Economize 20%
              </Badge>
            </motion.div>
          </motion.div>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {plans.map((plan, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 50 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: 0.2 + index * 0.1, duration: 0.6 }}
              whileHover={{ y: -8 }}
              className="relative"
            >
              <Card
                className={`p-8 relative h-full backdrop-blur-sm transition-all duration-500 ${
                  plan.popular 
                    ? 'border-primary border-2 bg-gradient-to-b from-primary/5 to-transparent shadow-2xl shadow-primary/20' 
                    : 'border-primary/10 bg-card/50 hover:border-primary/30'
                }`}
                data-testid={`card-pricing-${index}`}
              >
                {plan.popular && (
                  <motion.div
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.5 }}
                    className="absolute -top-4 left-1/2 transform -translate-x-1/2"
                  >
                    <Badge className="bg-gradient-to-r from-primary via-primary to-primary/80 border-0 shadow-xl px-4 py-1" data-testid="badge-popular">
                      <Sparkles className="h-3 w-3 mr-1 inline" />
                      Mais popular
                    </Badge>
                  </motion.div>
                )}

                {plan.popular && (
                  <motion.div
                    className="absolute -inset-0.5 bg-gradient-to-r from-primary via-primary/50 to-primary rounded-lg blur opacity-20"
                    animate={{
                      opacity: [0.2, 0.3, 0.2],
                    }}
                    transition={{
                      duration: 3,
                      repeat: Infinity,
                      ease: "easeInOut"
                    }}
                  />
                )}
              
              <div className="mb-6 relative z-10">
                <h3 className="text-2xl font-semibold mb-2" data-testid={`text-plan-name-${index}`}>
                  {plan.name}
                </h3>
                <p className="text-muted-foreground text-sm" data-testid={`text-plan-description-${index}`}>
                  {plan.description}
                </p>
              </div>

              <motion.div 
                className="mb-8 relative z-10"
                key={annual ? 'annual' : 'monthly'}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
              >
                {plan.monthlyPrice ? (
                  <>
                    <div className="flex items-baseline gap-1">
                      <span className={`text-4xl font-bold font-mono ${plan.popular ? 'bg-gradient-to-r from-primary to-primary/70 bg-clip-text text-transparent' : ''}`} data-testid={`text-plan-price-${index}`}>
                        R$ {annual ? plan.annualPrice : plan.monthlyPrice}
                      </span>
                      <span className="text-muted-foreground">/{annual ? 'ano' : 'mês'}</span>
                    </div>
                    {annual && (
                      <motion.p 
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        className="text-sm text-muted-foreground mt-1"
                      >
                        R$ {Math.round(plan.annualPrice! / 12)}/mês quando cobrado anualmente
                      </motion.p>
                    )}
                  </>
                ) : (
                  <div className="text-3xl font-bold bg-gradient-to-r from-foreground to-foreground/70 bg-clip-text text-transparent" data-testid={`text-plan-price-${index}`}>
                    Personalizado
                  </div>
                )}
              </motion.div>

              <motion.div
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="relative z-10"
              >
                <Button 
                  className={`w-full mb-6 relative overflow-hidden group ${
                    plan.popular ? 'shadow-xl shadow-primary/30' : ''
                  }`}
                  variant={plan.popular ? "default" : "outline"}
                  data-testid={`button-plan-cta-${index}`}
                >
                  {plan.popular && (
                    <motion.div
                      className="absolute inset-0 bg-gradient-to-r from-primary/0 via-white/20 to-primary/0"
                      animate={{ x: ['-200%', '200%'] }}
                      transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
                    />
                  )}
                  <span className="relative z-10">{plan.cta}</span>
                </Button>
              </motion.div>

              <div className="space-y-3 relative z-10">
                {plan.features.map((feature, featureIndex) => (
                  <motion.div 
                    key={featureIndex}
                    initial={{ opacity: 0, x: -10 }}
                    animate={isInView ? { opacity: 1, x: 0 } : {}}
                    transition={{ delay: 0.4 + index * 0.1 + featureIndex * 0.05 }}
                    className="flex items-start gap-3 group/feature"
                    data-testid={`text-plan-feature-${index}-${featureIndex}`}
                  >
                    <motion.div
                      whileHover={{ scale: 1.2, rotate: 360 }}
                      transition={{ type: "spring", stiffness: 300, damping: 10 }}
                    >
                      <div className="h-5 w-5 rounded-full bg-primary/10 flex items-center justify-center group-hover/feature:bg-primary/20 transition-colors">
                        <Check className="h-3 w-3 text-primary" />
                      </div>
                    </motion.div>
                    <span className="text-sm group-hover/feature:text-foreground transition-colors">{feature}</span>
                  </motion.div>
                ))}
              </div>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
